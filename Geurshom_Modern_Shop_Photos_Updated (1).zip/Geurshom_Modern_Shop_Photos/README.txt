GEURSHOM MODERN SHOP — WEBSITE FILES

1. Fungura index.html muri browser kugira ngo urebe urubuga.
2. Folder images igomba kugumana na index.html.
3. Kugira ngo ushyire ku rubuga, shyira index.html na folder images muri GitHub Pages, Netlify cyangwa hosting yawe.
4. Nimero ya WhatsApp ikoreshwa mu gutumiza: +250 780 989 311.
5. Ibiciro biri muri website ni iby'icyitegererezo. Hindura muri index.html mbere yo gutangaza urubuga.
6. Amafoto ari muri images ni amashusho yakozwe na AI (realistic sample visuals), ntabwo ari amafoto yemeza ibicuruzwa nyabyo biri mu bubiko. Ushobora gusimbuza buri JPG n'ifoto yawe nyayo, ugakomeza gukoresha izina rya file rimwe.
7. Kwiyandikisha kuri website itegura ubutumwa bwo kohereza kuri WhatsApp; ntibika amakuru muri database.
